pakai php v7.4
mysql
biasanya run di local pakai xampp v3.3.0
mending pakai db yang di dev 
